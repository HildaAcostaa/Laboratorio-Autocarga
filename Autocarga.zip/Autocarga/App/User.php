<?php
namespace App;
Class User {
    public function getname():string 
    {
        return "Dave";
    }
}

?>