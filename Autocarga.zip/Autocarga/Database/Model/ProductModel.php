<?php
namespace Database\Model;

Class ProductModel {
    public function getId():int 
    {
        return 123;
    }
}

?>
